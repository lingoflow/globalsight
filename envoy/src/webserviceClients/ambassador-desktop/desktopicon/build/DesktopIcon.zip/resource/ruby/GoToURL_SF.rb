require 'rubygems'
require 'safariwatir'

browser = Watir::Safari.new
browser.goto("")
$username = " "
$password = " "
$server_url = " "